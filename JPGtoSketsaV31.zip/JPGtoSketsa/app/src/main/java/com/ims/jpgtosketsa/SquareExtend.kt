package com.ims.jpgtosketsa

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Membuat gambar persegi 1:1 TANPA memotong objek: foto diletakkan di tengah kanvas persegi dan
 * sisi yang kosong diisi.
 *  - fill 1 = perluas latar: tepi foto diregangkan lalu di-blur kuat (selapis tonal lembut) dan makin
 *             ke luar makin memudar ke kertas, sehingga tampak seperti sketsa yang menghilang di tepi.
 *  - fill 2 = kertas polos.
 * Sengaja tidak memakai cermin: cermin menggandakan lengan/objek di tepi foto menjadi "hantu".
 */
object SquareExtend {
    /** Foto asli berada di (ox, oy, w, h) di dalam bmp persegi. */
    class Result(val bmp: Bitmap, val ox: Int, val oy: Int, val w: Int, val h: Int)

    private const val VIGNETTE = 0.60f   // seberapa pudar ke kertas di tepi terluar
    private const val RAMP = 0.10f       // lebar peralihan ke versi blur (kali sisi persegi)
    private const val W0 = 0.92f         // porsi versi blur tepat di tepi foto

    fun apply(src: Bitmap, fill: Int): Result {
        val w = src.width
        val h = src.height
        val s = max(w, h)
        if (abs(w - h) <= s * 0.03f) return Result(src, 0, 0, w, h)   // sudah (hampir) persegi
        val ox = (s - w) / 2
        val oy = (s - h) / 2
        val sp = IntArray(w * h)
        src.getPixels(sp, 0, w, 0, 0, w, h)
        val out = IntArray(s * s)

        if (fill == 2) {
            java.util.Arrays.fill(out, Color.WHITE)
        } else {
            // Versi blur kuat dari tepi yang diregangkan (dihitung di resolusi kecil lalu diperbesar)
            val sm = min(s, 300)
            val small = IntArray(sm * sm)
            for (y in 0 until sm) {
                val sy = ((y + 0.5f) * s / sm - oy).toInt().coerceIn(0, h - 1)
                for (x in 0 until sm) {
                    val sx = ((x + 0.5f) * s / sm - ox).toInt().coerceIn(0, w - 1)
                    small[y * sm + x] = sp[sy * w + sx]
                }
            }
            boxBlur(small, sm, sm, 16)
            val sb = Bitmap.createBitmap(small, sm, sm, Bitmap.Config.ARGB_8888)
            val bb = Bitmap.createScaledBitmap(sb, s, s, true)
            if (bb !== sb) sb.recycle()
            val bp = IntArray(s * s)
            bb.getPixels(bp, 0, s, 0, 0, s, s)
            bb.recycle()

            val ramp = max(1f, RAMP * s)
            val far = max(max(ox, oy), 1).toFloat()
            for (y in 0 until s) {
                val dy = max(max(oy - y, y - (oy + h - 1)), 0)
                for (x in 0 until s) {
                    val dx = max(max(ox - x, x - (ox + w - 1)), 0)
                    val i = y * s + x
                    if (dx == 0 && dy == 0) { out[i] = sp[(y - oy) * w + (x - ox)]; continue }
                    val d = sqrt((dx * dx + dy * dy).toFloat())
                    val ex = sp[(y - oy).coerceIn(0, h - 1) * w + (x - ox).coerceIn(0, w - 1)]
                    val t = (d / ramp).coerceIn(0f, 1f)
                    val wgt = W0 + (1f - W0) * (t * t * (3f - 2f * t))
                    val tv = (d / far).coerceIn(0f, 1f)
                    val f = VIGNETTE * (tv * tv * (3f - 2f * tv))
                    val b = bp[i]
                    val r = (Color.red(ex) * (1f - wgt) + Color.red(b) * wgt) * (1f - f) + 255f * f
                    val g = (Color.green(ex) * (1f - wgt) + Color.green(b) * wgt) * (1f - f) + 255f * f
                    val bl = (Color.blue(ex) * (1f - wgt) + Color.blue(b) * wgt) * (1f - f) + 255f * f
                    out[i] = Color.rgb(r.roundToInt().coerceIn(0, 255), g.roundToInt().coerceIn(0, 255), bl.roundToInt().coerceIn(0, 255))
                }
            }
            return Result(finish(out, s, sp, w, h, ox, oy), ox, oy, w, h)
        }
        return Result(finish(out, s, sp, w, h, ox, oy), ox, oy, w, h)
    }

    private fun finish(out: IntArray, s: Int, sp: IntArray, w: Int, h: Int, ox: Int, oy: Int): Bitmap {
        for (y in 0 until h) System.arraycopy(sp, y * w, out, (y + oy) * s + ox, w)   // foto asli tetap utuh
        return Bitmap.createBitmap(out, s, s, Bitmap.Config.ARGB_8888)
    }

    /** Blur kotak 2 lintasan (horizontal lalu vertikal) pada piksel RGB, tepi di-clamp. */
    private fun boxBlur(p: IntArray, w: Int, h: Int, r: Int) {
        val tmp = IntArray(w * h)
        val k = 2 * r + 1
        repeat(2) {
            for (y in 0 until h) {
                val o = y * w
                var sr = 0; var sg = 0; var sb = 0
                for (i in -r..r) { val c = p[o + i.coerceIn(0, w - 1)]; sr += Color.red(c); sg += Color.green(c); sb += Color.blue(c) }
                for (x in 0 until w) {
                    tmp[o + x] = Color.rgb(sr / k, sg / k, sb / k)
                    val a = p[o + min(x + r + 1, w - 1)]
                    val b = p[o + max(x - r, 0)]
                    sr += Color.red(a) - Color.red(b); sg += Color.green(a) - Color.green(b); sb += Color.blue(a) - Color.blue(b)
                }
            }
            for (x in 0 until w) {
                var sr = 0; var sg = 0; var sb = 0
                for (i in -r..r) { val c = tmp[i.coerceIn(0, h - 1) * w + x]; sr += Color.red(c); sg += Color.green(c); sb += Color.blue(c) }
                for (y in 0 until h) {
                    p[y * w + x] = Color.rgb(sr / k, sg / k, sb / k)
                    val a = tmp[min(y + r + 1, h - 1) * w + x]
                    val b = tmp[max(y - r, 0) * w + x]
                    sr += Color.red(a) - Color.red(b); sg += Color.green(a) - Color.green(b); sb += Color.blue(a) - Color.blue(b)
                }
            }
        }
    }
}
