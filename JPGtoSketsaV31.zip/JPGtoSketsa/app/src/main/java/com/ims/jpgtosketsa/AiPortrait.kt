package com.ims.jpgtosketsa

import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Model AI offline U2-Net Portrait (Apache-2.0): foto -> gambar garis pensil.
 * File model (u2net_portrait.onnx, sekitar 176 MB) ditaruh di assets saat build GitHub.
 */
object AiPortrait {
    private const val ASSET = "u2net_portrait.onnx"
    private const val S = 512

    private var appCtx: Context? = null
    private var env: OrtEnvironment? = null
    private var session: OrtSession? = null

    private var cacheKey = 0L
    private var cacheRaw: ByteArray? = null

    @Volatile var lastError: String = ""

    fun init(c: Context) { appCtx = c.applicationContext }

    fun available(): Boolean = try {
        appCtx?.assets?.open(ASSET)?.close()
        appCtx != null
    } catch (e: Exception) { false }

    private fun ensureSession(): OrtSession {
        session?.let { return it }
        val ctx = appCtx ?: throw IllegalStateException("AiPortrait belum diinisialisasi")
        val f = File(ctx.filesDir, ASSET)
        if (!f.exists() || f.length() < 100_000_000L) {
            val tmp = File(ctx.filesDir, "$ASSET.tmp")
            ctx.assets.open(ASSET).use { i -> tmp.outputStream().use { o -> i.copyTo(o, 1 shl 20) } }
            if (f.exists()) f.delete()
            tmp.renameTo(f)
        }
        val e = OrtEnvironment.getEnvironment()
        val so = OrtSession.SessionOptions()
        so.setIntraOpNumThreads(4)
        val s = e.createSession(f.absolutePath, so)
        env = e
        session = s
        return s
    }

    /** Sidik sederhana dari isi gambar supaya hasil AI bisa dipakai ulang saat slider digeser. */
    private fun keyOf(src: Bitmap): Long {
        var k = src.width * 31L + src.height
        val w = src.width
        val h = src.height
        for (j in 0 until 16) for (i in 0 until 16) {
            k = k * 1000003L + src.getPixel((i * 2 + 1) * (w - 1) / 32, (j * 2 + 1) * (h - 1) / 32)
        }
        return k
    }

    /**
     * Mengembalikan kecerahan 0..255 per piksel (ukuran sama dengan src): putih = kertas, gelap = goresan.
     * null jika model tidak ada atau gagal (lihat lastError).
     */
    @Synchronized
    fun lines(src: Bitmap): IntArray? {
        return try {
            val w = src.width
            val h = src.height
            val sc = S.toFloat() / max(w, h)
            val nw = max(1, (w * sc).roundToInt())
            val nh = max(1, (h * sc).roundToInt())
            val offX = (S - nw) / 2
            val offY = (S - nh) / 2

            val key = keyOf(src)
            var raw = cacheRaw
            if (raw == null || key != cacheKey) {
                val sess = ensureSession()
                val sm = Bitmap.createScaledBitmap(src, nw, nh, true)
                val px = IntArray(nw * nh)
                sm.getPixels(px, 0, nw, 0, 0, nw, nh)
                val buf = ByteBuffer.allocateDirect(S * S * 3).order(ByteOrder.nativeOrder())
                for (y in 0 until S) {
                    val sy = (y - offY).coerceIn(0, nh - 1)
                    for (x in 0 until S) {
                        val sx = (x - offX).coerceIn(0, nw - 1)
                        val c = px[sy * nw + sx]
                        buf.put(Color.blue(c).toByte())
                        buf.put(Color.green(c).toByte())
                        buf.put(Color.red(c).toByte())
                    }
                }
                buf.rewind()
                val tensor = OnnxTensor.createTensor(env, buf, longArrayOf(1, S.toLong(), S.toLong(), 3), OnnxJavaType.UINT8)
                val res = sess.run(mapOf(sess.inputNames.first() to tensor))
                val ob = (res.get(0) as OnnxTensor).byteBuffer
                ob.rewind()
                val r = ByteArray(S * S)
                ob.get(r)
                res.close()
                tensor.close()
                raw = r
                cacheRaw = r
                cacheKey = key
            }

            // Perbesar ke ukuran asli (bilinear), buang bagian pinggiran letterbox
            val x0 = IntArray(w)
            val xt = FloatArray(w)
            for (x in 0 until w) {
                val g = ((x + 0.5f) * nw / w - 0.5f + offX).coerceIn(offX.toFloat(), (offX + nw - 1).toFloat())
                val i0 = floor(g).toInt()
                x0[x] = min(i0, offX + nw - 2).coerceAtLeast(offX)
                xt[x] = g - x0[x]
            }
            val out = IntArray(w * h)
            for (y in 0 until h) {
                val g = ((y + 0.5f) * nh / h - 0.5f + offY).coerceIn(offY.toFloat(), (offY + nh - 1).toFloat())
                val j0 = min(floor(g).toInt(), offY + nh - 2).coerceAtLeast(offY)
                val ty = g - j0
                val j1 = min(j0 + 1, S - 1)
                for (x in 0 until w) {
                    val i0 = x0[x]
                    val i1 = min(i0 + 1, S - 1)
                    val a = (raw[j0 * S + i0].toInt() and 0xFF) * (1f - xt[x]) + (raw[j0 * S + i1].toInt() and 0xFF) * xt[x]
                    val b = (raw[j1 * S + i0].toInt() and 0xFF) * (1f - xt[x]) + (raw[j1 * S + i1].toInt() and 0xFF) * xt[x]
                    out[y * w + x] = (a * (1f - ty) + b * ty).toInt().coerceIn(0, 255)
                }
            }
            lastError = ""
            out
        } catch (t: Throwable) {
            lastError = t.javaClass.simpleName + ": " + (t.message ?: "")
            null
        }
    }
}
