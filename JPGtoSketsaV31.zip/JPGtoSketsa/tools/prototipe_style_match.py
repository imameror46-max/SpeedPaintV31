import numpy as np, cv2
from PIL import Image
U='/mnt/user-data/uploads/'
c=np.array(Image.open(U+'167144.png').convert('L'),np.float32)
a=np.array(Image.open(U+'167717.jpg').convert('L'),np.float32)
al=np.array(Image.open(U+'167718.png'))[...,3].astype(np.float32)/255
al=cv2.resize(al,(a.shape[1],a.shape[0]),interpolation=cv2.INTER_LINEAR)
b=(al>0.5).astype(np.uint8)
b=cv2.morphologyEx(b,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(45,45)))
cnts,_=cv2.findContours(b,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
f=np.zeros_like(b); cv2.drawContours(f,cnts,-1,1,-1)      # isi semua lubang
al=cv2.GaussianBlur(f.astype(np.float32),(0,0),1.5)
# sampel master: wajah+baju Canva ; sampel foto: wajah+baju aplikasi
cs=np.concatenate([c[190:390,540:770].ravel(),c[560:800,450:850].ravel()])
as_=np.concatenate([a[200:480,480:780].ravel(),a[800:1200,350:850].ravel()])
q=np.linspace(0,100,101)
cq=np.percentile(cs,q); aq=np.percentile(as_,q)
lut=np.interp(np.arange(256),aq,cq)           # histogram matching
lut=cv2.GaussianBlur(lut.astype(np.float32).reshape(1,-1),(0,0),2).ravel()
m=lut[np.clip(a,0,255).astype(int)]
# kuatkan tekstur goresan (band-pass halus), meniru kontras tekstur Canva
low=cv2.GaussianBlur(m,(0,0),1.2); mid=cv2.GaussianBlur(m,(0,0),5)
band=low-mid
m=m+0.5*band
m=np.clip(m,38,252)
# subjek saja; latar putih bersih
out=m*al+255*(1-al)
out=np.clip(out,0,255).astype(np.uint8)
Image.fromarray(out).save('proto_out2.png')
# statistik ulang
def st(n,x): print(n,'mean %.0f p5 %.0f p50 %.0f p95 %.0f'%(x.mean(),*np.percentile(x,[5,50,95])))
st('canva shirt',c[560:800,450:850]); st('app lama shirt',a[800:1200,350:850]); st('proto shirt',out[800:1200,350:850].astype(float))
st('canva face',c[190:390,540:770]); st('app lama face',a[200:480,480:780]); st('proto face',out[200:480,480:780].astype(float))
def tex(x):
    x=x-cv2.GaussianBlur(x,(0,0),12); return x.std()
print('tekstur baju: canva %.1f lama %.1f proto %.1f'%(tex(c[580:780,480:880]),tex(a[850:1150,380:880]),tex(out[850:1150,380:880].astype(np.float32))))
# gambar perbandingan
cc=Image.fromarray(c.astype(np.uint8)).crop((200,40,1064,1264)).resize((600,850))
pp=Image.fromarray(out).resize((549,850))
aa=Image.fromarray(a.astype(np.uint8)).resize((549,850))
mm=Image.new('L',(1698,850),255); mm.paste(aa,(0,0)); mm.paste(pp,(549,0)); mm.paste(cc,(1098,0)); mm.save('cmp4.png')
